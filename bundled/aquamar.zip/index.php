<?php get_header(); ?>
<h1>Hello lumeee</h1>
<?php get_footer(); ?>